# 📚 StudyShop — E-commerce de documents d'études

Plateforme fullstack pour la vente en ligne de documents pédagogiques (cours, exercices, fiches de révision).

## 🗂️ Structure du projet

```
studyshop/
├── backend/              # API Node.js + Express + PostgreSQL
│   ├── config/
│   │   ├── db.js         # Pool de connexion PostgreSQL
│   │   └── schema.sql    # Schéma complet de la base de données
│   ├── controllers/      # Logique métier
│   │   ├── authController.js
│   │   ├── documentController.js
│   │   ├── orderController.js
│   │   └── categoryController.js
│   ├── middleware/
│   │   └── auth.js       # Middleware JWT
│   ├── routes/
│   │   └── index.js      # Toutes les routes API
│   ├── .env.example
│   └── server.js
│
└── frontend/             # React 18 + Tailwind CSS
    ├── src/
    │   ├── components/
    │   │   ├── Navbar.jsx
    │   │   └── DocumentCard.jsx
    │   ├── context/
    │   │   ├── AuthContext.jsx
    │   │   └── CartContext.jsx
    │   ├── pages/
    │   │   ├── HomePage.jsx
    │   │   ├── CataloguePage.jsx
    │   │   ├── DocumentPage.jsx
    │   │   ├── CartPage.jsx
    │   │   ├── PurchasesPage.jsx
    │   │   └── AuthPages.jsx
    │   └── utils/
    │       └── api.js    # Client Axios centralisé
    └── public/
```

## 🚀 Installation & Démarrage

### Prérequis
- Node.js 18+
- PostgreSQL 14+
- npm ou yarn

---

### 1. Base de données PostgreSQL

```sql
-- Dans psql ou pgAdmin
CREATE DATABASE studyshop;
\c studyshop
\i backend/config/schema.sql
```

---

### 2. Backend

```bash
cd backend
cp .env.example .env
# Éditez .env avec vos paramètres DB, JWT_SECRET, etc.

npm install
npm run dev   # Démarre sur http://localhost:5000
```

#### Variables d'environnement backend (.env)
| Variable | Description |
|---|---|
| `DB_HOST` | Hôte PostgreSQL (ex: localhost) |
| `DB_PORT` | Port PostgreSQL (ex: 5432) |
| `DB_NAME` | Nom de la base (studyshop) |
| `DB_USER` | Utilisateur PostgreSQL |
| `DB_PASSWORD` | Mot de passe PostgreSQL |
| `JWT_SECRET` | Clé secrète JWT (chaîne aléatoire longue) |
| `JWT_EXPIRES_IN` | Durée du token (ex: 7d) |
| `STRIPE_SECRET_KEY` | Clé Stripe (optionnel en dev) |
| `CLIENT_URL` | URL du frontend (http://localhost:3000) |

---

### 3. Frontend

```bash
cd frontend
npm install
npm start   # Démarre sur http://localhost:3000
```

---

## 📡 Endpoints API

### Authentification
| Méthode | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Inscription |
| POST | `/api/auth/login` | Connexion → JWT |
| GET | `/api/auth/me` | Profil courant |

### Documents
| Méthode | Endpoint | Description |
|---|---|---|
| GET | `/api/documents` | Liste (filtres: category, level, search, sort, page) |
| GET | `/api/documents/:id` | Détail + avis |
| POST | `/api/documents` | Créer (admin) |
| PATCH | `/api/documents/:id` | Modifier (admin) |
| DELETE | `/api/documents/:id` | Supprimer (admin) |
| GET | `/api/documents/:id/download` | URL de téléchargement (acheteurs) |
| POST | `/api/documents/:id/reviews` | Ajouter un avis (acheteurs) |

### Panier & Commandes
| Méthode | Endpoint | Description |
|---|---|---|
| GET | `/api/cart` | Voir le panier |
| POST | `/api/cart/:documentId` | Ajouter au panier |
| DELETE | `/api/cart/:documentId` | Retirer du panier |
| POST | `/api/orders` | Créer une commande |
| POST | `/api/orders/:id/confirm` | Confirmer le paiement |
| GET | `/api/orders` | Historique des commandes |
| GET | `/api/purchases` | Documents achetés |

### Admin
| Méthode | Endpoint | Description |
|---|---|---|
| GET | `/api/admin/stats` | Statistiques globales |

---

## 🗄️ Modèle de données (PostgreSQL)

```
users ──────────────────────────────────────┐
  id, email, password_hash, full_name,       │
  role (customer/admin/seller), created_at   │
                                             │
categories                                   │
  id, name, slug, description, icon, color   │
                                             │
documents ────────────────────────────────── │
  id, title, description, price,            │
  category_id → categories,                  │
  seller_id → users,                         │
  file_url, preview_url, thumbnail_url,      │
  level, subject_tags[], rating_avg          │
                                             │
orders → users                               │
  id, user_id, status, total_amount          │
                                             │
order_items → orders, documents              │
  order_id, document_id, price_at_purchase   │
                                             │
purchases → users, documents ← (accès)       │
  user_id, document_id, order_id             │
                                             │
reviews → users, documents                   │
  rating (1-5), comment                      │
                                             │
cart_items → users, documents                │
  user_id, document_id                        │
```

---

## 🔌 Intégration Stripe (paiement réel)

Dans `orderController.js`, décommentez le bloc Stripe :

```js
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const paymentIntent = await stripe.paymentIntents.create({
  amount: Math.round(total * 100),
  currency: 'xof',  // Franc CFA
});
// Renvoyer client_secret au frontend
```

Côté frontend, intégrez `@stripe/react-stripe-js` pour le formulaire de carte.

---

## 📦 Stack technique

| Couche | Technologies |
|---|---|
| Frontend | React 18, React Router 6, Tailwind CSS 3, Axios |
| Backend | Node.js, Express 4, JWT (jsonwebtoken), bcryptjs |
| Base de données | PostgreSQL 14+, pg (node-postgres) |
| Paiements | Stripe (prêt à intégrer) |
| Auth | JWT Bearer token, stockage localStorage |
