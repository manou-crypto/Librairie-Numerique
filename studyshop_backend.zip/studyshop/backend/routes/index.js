const express = require('express');
const router = express.Router();
const { authenticate, isAdmin } = require('../middleware/auth');
const authCtrl = require('../controllers/authController');
const docCtrl = require('../controllers/documentController');
const orderCtrl = require('../controllers/orderController');
const catCtrl = require('../controllers/categoryController');

// ========== AUTH ==========
router.post('/auth/register', authCtrl.register);
router.post('/auth/login', authCtrl.login);
router.get('/auth/me', authenticate, authCtrl.getMe);

// ========== CATEGORIES ==========
router.get('/categories', catCtrl.getCategories);

// ========== DOCUMENTS ==========
router.get('/documents', docCtrl.getDocuments);
router.get('/documents/:id', docCtrl.getDocumentById);
router.post('/documents', authenticate, isAdmin, docCtrl.createDocument);
router.patch('/documents/:id', authenticate, isAdmin, docCtrl.updateDocument);
router.delete('/documents/:id', authenticate, isAdmin, docCtrl.deleteDocument);
router.get('/documents/:id/download', authenticate, docCtrl.downloadDocument);

// Reviews
router.post('/documents/:documentId/reviews', authenticate, catCtrl.addReview);

// ========== CART ==========
router.get('/cart', authenticate, orderCtrl.getCart);
router.post('/cart/:documentId', authenticate, orderCtrl.addToCart);
router.delete('/cart/:documentId', authenticate, orderCtrl.removeFromCart);

// ========== ORDERS ==========
router.post('/orders', authenticate, orderCtrl.createOrder);
router.post('/orders/:orderId/confirm', authenticate, orderCtrl.confirmOrder);
router.get('/orders', authenticate, orderCtrl.getOrders);

// ========== PURCHASES ==========
router.get('/purchases', authenticate, orderCtrl.getPurchases);

// ========== ADMIN ==========
router.get('/admin/stats', authenticate, isAdmin, catCtrl.getAdminStats);

module.exports = router;
