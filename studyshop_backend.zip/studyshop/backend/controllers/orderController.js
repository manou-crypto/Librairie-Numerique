const pool = require('../config/db');
const { v4: uuidv4 } = require('uuid');

// ========== CART ==========

// GET /api/cart
const getCart = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT ci.id, d.id AS document_id, d.title, d.price, d.thumbnail_url,
              d.level, c.name AS category_name, c.color AS category_color
       FROM cart_items ci
       JOIN documents d ON ci.document_id = d.id
       LEFT JOIN categories c ON d.category_id = c.id
       WHERE ci.user_id = $1`,
      [req.user.id]
    );
    const total = rows.reduce((sum, item) => sum + parseFloat(item.price), 0);
    res.json({ items: rows, total: parseFloat(total.toFixed(2)) });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// POST /api/cart/:documentId
const addToCart = async (req, res) => {
  try {
    const { documentId } = req.params;
    const userId = req.user.id;

    // Vérifier si déjà acheté
    const purchased = await pool.query(
      'SELECT id FROM purchases WHERE user_id = $1 AND document_id = $2',
      [userId, documentId]
    );
    if (purchased.rows.length) {
      return res.status(400).json({ error: 'Vous possédez déjà ce document' });
    }

    await pool.query(
      'INSERT INTO cart_items (user_id, document_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [userId, documentId]
    );

    res.status(201).json({ message: 'Ajouté au panier' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// DELETE /api/cart/:documentId
const removeFromCart = async (req, res) => {
  try {
    await pool.query(
      'DELETE FROM cart_items WHERE user_id = $1 AND document_id = $2',
      [req.user.id, req.params.documentId]
    );
    res.json({ message: 'Retiré du panier' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// ========== ORDERS ==========

// POST /api/orders  — crée la commande + intent Stripe
const createOrder = async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const userId = req.user.id;

    // Récupérer les items du panier
    const { rows: cartItems } = await client.query(
      `SELECT ci.document_id, d.price, d.title
       FROM cart_items ci JOIN documents d ON ci.document_id = d.id
       WHERE ci.user_id = $1 AND d.is_published = TRUE`,
      [userId]
    );

    if (!cartItems.length) {
      return res.status(400).json({ error: 'Le panier est vide' });
    }

    const total = cartItems.reduce((sum, i) => sum + parseFloat(i.price), 0);

    // Créer la commande
    const { rows: [order] } = await client.query(
      `INSERT INTO orders (user_id, total_amount, status)
       VALUES ($1, $2, 'pending') RETURNING *`,
      [userId, total.toFixed(2)]
    );

    // Insérer les lignes
    for (const item of cartItems) {
      await client.query(
        `INSERT INTO order_items (order_id, document_id, price_at_purchase)
         VALUES ($1, $2, $3)`,
        [order.id, item.document_id, item.price]
      );
    }

    await client.query('COMMIT');

    // Note: en production, créer un PaymentIntent Stripe ici
    // const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
    // const paymentIntent = await stripe.paymentIntents.create({ amount: Math.round(total * 100), currency: 'xof' });

    res.status(201).json({
      order,
      items: cartItems,
      // client_secret: paymentIntent.client_secret
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('createOrder error:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  } finally {
    client.release();
  }
};

// POST /api/orders/:orderId/confirm  — simule la confirmation de paiement
const confirmOrder = async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { orderId } = req.params;

    const { rows: [order] } = await client.query(
      `UPDATE orders SET status = 'paid' WHERE id = $1 AND user_id = $2 RETURNING *`,
      [orderId, req.user.id]
    );

    if (!order) return res.status(404).json({ error: 'Commande introuvable' });

    // Créer les accès (purchases)
    const { rows: items } = await client.query(
      'SELECT document_id FROM order_items WHERE order_id = $1',
      [orderId]
    );

    for (const item of items) {
      await client.query(
        `INSERT INTO purchases (user_id, document_id, order_id)
         VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`,
        [req.user.id, item.document_id, orderId]
      );
    }

    // Vider le panier
    await client.query('DELETE FROM cart_items WHERE user_id = $1', [req.user.id]);

    await client.query('COMMIT');
    res.json({ order, message: 'Paiement confirmé' });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Erreur serveur' });
  } finally {
    client.release();
  }
};

// GET /api/orders  — historique
const getOrders = async (req, res) => {
  try {
    const { rows: orders } = await pool.query(
      `SELECT o.*, json_agg(json_build_object(
         'document_id', oi.document_id,
         'title', d.title,
         'price', oi.price_at_purchase,
         'thumbnail_url', d.thumbnail_url
       )) AS items
       FROM orders o
       LEFT JOIN order_items oi ON o.id = oi.order_id
       LEFT JOIN documents d ON oi.document_id = d.id
       WHERE o.user_id = $1
       GROUP BY o.id ORDER BY o.created_at DESC`,
      [req.user.id]
    );
    res.json({ orders });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// GET /api/purchases  — documents achetés
const getPurchases = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT p.purchased_at, p.downloaded_count,
              d.id, d.title, d.thumbnail_url, d.level, d.file_type,
              c.name AS category_name, c.color AS category_color
       FROM purchases p
       JOIN documents d ON p.document_id = d.id
       LEFT JOIN categories c ON d.category_id = c.id
       WHERE p.user_id = $1 ORDER BY p.purchased_at DESC`,
      [req.user.id]
    );
    res.json({ purchases: rows });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

module.exports = { getCart, addToCart, removeFromCart, createOrder, confirmOrder, getOrders, getPurchases };
