const pool = require('../config/db');

// ========== CATEGORIES ==========

const getCategories = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT c.*, COUNT(d.id)::int AS document_count
       FROM categories c
       LEFT JOIN documents d ON d.category_id = c.id AND d.is_published = TRUE
       WHERE c.parent_id IS NULL
       GROUP BY c.id ORDER BY c.name`
    );
    res.json({ categories: rows });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// ========== REVIEWS ==========

const addReview = async (req, res) => {
  try {
    const { documentId } = req.params;
    const { rating, comment } = req.body;

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Note entre 1 et 5 requise' });
    }

    // Vérifier l'achat
    const purchased = await pool.query(
      'SELECT id FROM purchases WHERE user_id = $1 AND document_id = $2',
      [req.user.id, documentId]
    );
    if (!purchased.rows.length) {
      return res.status(403).json({ error: 'Vous devez acheter ce document pour l\'évaluer' });
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      await client.query(
        `INSERT INTO reviews (user_id, document_id, rating, comment)
         VALUES ($1, $2, $3, $4) ON CONFLICT (user_id, document_id) DO UPDATE
         SET rating = $3, comment = $4`,
        [req.user.id, documentId, rating, comment]
      );

      // Recalculer la moyenne
      await client.query(
        `UPDATE documents SET
           rating_avg = (SELECT AVG(rating) FROM reviews WHERE document_id = $1),
           rating_count = (SELECT COUNT(*) FROM reviews WHERE document_id = $1)
         WHERE id = $1`,
        [documentId]
      );

      await client.query('COMMIT');
      res.status(201).json({ message: 'Avis enregistré' });
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// ========== ADMIN STATS ==========

const getAdminStats = async (req, res) => {
  try {
    const [users, docs, orders, revenue] = await Promise.all([
      pool.query('SELECT COUNT(*)::int AS count FROM users'),
      pool.query('SELECT COUNT(*)::int AS count FROM documents WHERE is_published = TRUE'),
      pool.query('SELECT COUNT(*)::int AS count FROM orders WHERE status = \'paid\''),
      pool.query('SELECT COALESCE(SUM(total_amount), 0) AS total FROM orders WHERE status = \'paid\''),
    ]);

    const topDocs = await pool.query(
      `SELECT d.title, d.downloads_count, d.price, c.name AS category
       FROM documents d LEFT JOIN categories c ON d.category_id = c.id
       WHERE d.is_published = TRUE
       ORDER BY d.downloads_count DESC LIMIT 5`
    );

    res.json({
      stats: {
        total_users: users.rows[0].count,
        total_documents: docs.rows[0].count,
        total_orders: orders.rows[0].count,
        total_revenue: parseFloat(revenue.rows[0].total),
      },
      top_documents: topDocs.rows,
    });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

module.exports = { getCategories, addReview, getAdminStats };
