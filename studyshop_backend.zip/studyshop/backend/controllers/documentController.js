const pool = require('../config/db');

// GET /api/documents  — liste avec filtres + pagination
const getDocuments = async (req, res) => {
  try {
    const {
      category, level, search, sort = 'created_at',
      order = 'desc', page = 1, limit = 12, featured
    } = req.query;

    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(50, Math.max(1, parseInt(limit)));
    const offset = (pageNum - 1) * limitNum;

    const conditions = ['d.is_published = TRUE'];
    const params = [];
    let paramIdx = 1;

    if (category) {
      conditions.push(`c.slug = $${paramIdx++}`);
      params.push(category);
    }
    if (level) {
      conditions.push(`d.level = $${paramIdx++}`);
      params.push(level);
    }
    if (featured === 'true') {
      conditions.push(`d.is_featured = TRUE`);
    }
    if (search) {
      conditions.push(
        `to_tsvector('french', d.title || ' ' || COALESCE(d.description, '')) @@ plainto_tsquery('french', $${paramIdx++})`
      );
      params.push(search);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const allowedSort = { price: 'd.price', rating: 'd.rating_avg', downloads: 'd.downloads_count', created_at: 'd.created_at' };
    const sortCol = allowedSort[sort] || 'd.created_at';
    const sortDir = order === 'asc' ? 'ASC' : 'DESC';

    const query = `
      SELECT d.id, d.title, d.description, d.price, d.thumbnail_url,
             d.level, d.subject_tags, d.rating_avg, d.rating_count,
             d.downloads_count, d.file_type, d.page_count, d.created_at,
             c.name AS category_name, c.slug AS category_slug, c.color AS category_color,
             u.full_name AS seller_name
      FROM documents d
      LEFT JOIN categories c ON d.category_id = c.id
      LEFT JOIN users u ON d.seller_id = u.id
      ${where}
      ORDER BY ${sortCol} ${sortDir}
      LIMIT $${paramIdx++} OFFSET $${paramIdx++}
    `;
    params.push(limitNum, offset);

    const countQuery = `
      SELECT COUNT(*) FROM documents d
      LEFT JOIN categories c ON d.category_id = c.id
      ${where}
    `;

    const [data, count] = await Promise.all([
      pool.query(query, params),
      pool.query(countQuery, params.slice(0, -2)),
    ]);

    res.json({
      documents: data.rows,
      pagination: {
        total: parseInt(count.rows[0].count),
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(count.rows[0].count / limitNum),
      },
    });
  } catch (err) {
    console.error('getDocuments error:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// GET /api/documents/:id
const getDocumentById = async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT d.*, c.name AS category_name, c.slug AS category_slug,
              c.color AS category_color, u.full_name AS seller_name
       FROM documents d
       LEFT JOIN categories c ON d.category_id = c.id
       LEFT JOIN users u ON d.seller_id = u.id
       WHERE d.id = $1 AND d.is_published = TRUE`,
      [id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Document introuvable' });

    // Reviews
    const reviews = await pool.query(
      `SELECT r.rating, r.comment, r.created_at, u.full_name AS reviewer_name
       FROM reviews r JOIN users u ON r.user_id = u.id
       WHERE r.document_id = $1 ORDER BY r.created_at DESC LIMIT 10`,
      [id]
    );

    res.json({ document: rows[0], reviews: reviews.rows });
  } catch (err) {
    console.error('getDocumentById error:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// POST /api/documents  — admin/seller
const createDocument = async (req, res) => {
  try {
    const {
      title, description, price, category_id, level,
      subject_tags, file_url, preview_url, thumbnail_url,
      file_size, page_count, language
    } = req.body;

    if (!title || !price || !file_url) {
      return res.status(400).json({ error: 'Titre, prix et fichier sont requis' });
    }

    const { rows } = await pool.query(
      `INSERT INTO documents
         (title, description, price, category_id, seller_id, level, subject_tags,
          file_url, preview_url, thumbnail_url, file_size, page_count, language)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       RETURNING *`,
      [title, description, parseFloat(price), category_id, req.user.id, level,
       subject_tags, file_url, preview_url, thumbnail_url, file_size, page_count,
       language || 'fr']
    );

    res.status(201).json({ document: rows[0] });
  } catch (err) {
    console.error('createDocument error:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// PATCH /api/documents/:id
const updateDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const fields = ['title', 'description', 'price', 'category_id', 'level',
                    'subject_tags', 'thumbnail_url', 'preview_url',
                    'is_published', 'is_featured', 'page_count'];

    const updates = [];
    const params = [];
    let idx = 1;

    for (const field of fields) {
      if (req.body[field] !== undefined) {
        updates.push(`${field} = $${idx++}`);
        params.push(req.body[field]);
      }
    }

    if (!updates.length) return res.status(400).json({ error: 'Aucune modification fournie' });

    params.push(id);
    const { rows } = await pool.query(
      `UPDATE documents SET ${updates.join(', ')} WHERE id = $${idx} RETURNING *`,
      params
    );

    if (!rows.length) return res.status(404).json({ error: 'Document introuvable' });
    res.json({ document: rows[0] });
  } catch (err) {
    console.error('updateDocument error:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// DELETE /api/documents/:id
const deleteDocument = async (req, res) => {
  try {
    const { rows } = await pool.query(
      'DELETE FROM documents WHERE id = $1 RETURNING id',
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Document introuvable' });
    res.json({ message: 'Document supprimé' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// GET /api/documents/:id/download  — vérifie l'achat
const downloadDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const { rows } = await pool.query(
      'SELECT * FROM purchases WHERE user_id = $1 AND document_id = $2',
      [userId, id]
    );
    if (!rows.length) {
      return res.status(403).json({ error: 'Vous n\'avez pas acheté ce document' });
    }

    await pool.query(
      'UPDATE purchases SET downloaded_count = downloaded_count + 1 WHERE user_id = $1 AND document_id = $2',
      [userId, id]
    );
    await pool.query(
      'UPDATE documents SET downloads_count = downloads_count + 1 WHERE id = $1',
      [id]
    );

    const doc = await pool.query('SELECT file_url FROM documents WHERE id = $1', [id]);
    res.json({ download_url: doc.rows[0]?.file_url });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

module.exports = {
  getDocuments, getDocumentById, createDocument,
  updateDocument, deleteDocument, downloadDocument
};
