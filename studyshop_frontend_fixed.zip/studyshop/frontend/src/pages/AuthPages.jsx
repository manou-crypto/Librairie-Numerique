import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { BookOpen, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

function AuthPage({ mode }) {
  const [form, setForm] = useState({ email: '', password: '', full_name: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'register') {
        await register(form.email, form.password, form.full_name);
      } else {
        await login(form.email, form.password);
      }
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.response?.data?.error || 'Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-ink-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-primary-600 flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <h1 className="font-display text-2xl font-bold text-ink-900">
            {mode === 'register' ? 'Créer un compte' : 'Bon retour !'}
          </h1>
          <p className="text-ink-300 mt-1 text-sm">
            {mode === 'register' ? 'Rejoignez des milliers d\'étudiants' : 'Connectez-vous à StudyShop'}
          </p>
        </div>

        <div className="bg-white rounded-3xl border border-ink-100 shadow-float p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-sm font-medium text-ink-700 mb-1.5">Nom complet</label>
                <input
                  type="text"
                  value={form.full_name}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                  placeholder="Jean Dupont"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-ink-100 text-ink-900 placeholder-ink-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition bg-ink-50"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-ink-700 mb-1.5">Adresse email</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="jean@example.com"
                required
                className="w-full px-4 py-3 rounded-xl border border-ink-100 text-ink-900 placeholder-ink-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition bg-ink-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-ink-700 mb-1.5">Mot de passe</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder={mode === 'register' ? '8 caractères minimum' : '••••••••'}
                  required
                  className="w-full px-4 py-3 pr-11 rounded-xl border border-ink-100 text-ink-900 placeholder-ink-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition bg-ink-50"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-300 hover:text-ink-500 transition">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-100 text-red-600 text-sm rounded-xl px-4 py-3">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading}
              className="w-full py-3.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-xl transition flex items-center justify-center gap-2 disabled:opacity-60 mt-2">
              {loading ? (
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                mode === 'register' ? 'Créer mon compte' : 'Se connecter'
              )}
            </button>
          </form>

          <p className="text-center text-sm text-ink-300 mt-6">
            {mode === 'register' ? (
              <>Déjà un compte ? <Link to="/login" className="text-primary-600 font-medium hover:underline">Se connecter</Link></>
            ) : (
              <>Pas encore de compte ? <Link to="/register" className="text-primary-600 font-medium hover:underline">S'inscrire gratuitement</Link></>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

export const LoginPage = () => <AuthPage mode="login" />;
export const RegisterPage = () => <AuthPage mode="register" />;
