import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ShoppingCart, FileText, Download, Check, ChevronRight } from 'lucide-react';
import { documentsAPI } from '../utils/api';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import StarRating from '../components/StarRating';
import CategoryBadge from '../components/CategoryBadge';
import LevelBadge from '../components/LevelBadge';

const CAT_BG = {
  mathematiques: '#EEF3FB', 'physique-chimie': '#F3F0FC', svt: '#EDF7ED',
  informatique: '#FEF9E6', langues: '#FEF2EC', 'histoire-geo': '#F0F4FF',
  economie: '#FDF0F8', philosophie: '#F0FAFA',
};
const CAT_EMOJI = {
  mathematiques:'∑', 'physique-chimie':'⚗', svt:'🌿', informatique:'</>',
  langues:'📖', 'histoire-geo':'🌍', economie:'📈', philosophie:'💭',
};

export default function DocumentPage() {
  const { id }  = useParams();
  const navigate = useNavigate();
  const [doc, setDoc]         = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToCart, isInCart } = useCart();
  const { user } = useAuth();
  const inCart = doc ? isInCart(doc.id) : false;

  useEffect(() => {
    documentsAPI.getById(id)
      .then(({ data }) => { setDoc(data.document); setReviews(data.reviews); })
      .catch(() => navigate('/catalogue'))
      .finally(() => setLoading(false));
  }, [id, navigate]);

  const handleAddToCart = async () => {
    if (!user) return navigate('/login');
    await addToCart(doc.id);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-6 h-6 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );
  if (!doc) return null;

  const thumbBg = CAT_BG[doc.category_slug] || '#EEF3FB';
  const emoji   = CAT_EMOJI[doc.category_slug] || '📄';

  return (
    <div className="min-h-screen bg-ink-50 py-6">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Fil d'ariane */}
        <nav className="flex items-center gap-1.5 text-xs text-ink-300 mb-5">
          <Link to="/" className="hover:text-primary-600 transition-colors">Accueil</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to="/catalogue" className="hover:text-primary-600 transition-colors">Catalogue</Link>
          {doc.category_name && (
            <>
              <ChevronRight className="w-3 h-3" />
              <Link to={`/catalogue?category=${doc.category_slug}`} className="hover:text-primary-600 transition-colors">
                {doc.category_name}
              </Link>
            </>
          )}
          <ChevronRight className="w-3 h-3" />
          <span className="text-ink-600 truncate max-w-xs">{doc.title}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

          {/* ── Colonne principale ── */}
          <div className="lg:col-span-2 space-y-4">
            <div className="card p-5">
              <div className="h-24 rounded-xl flex items-center justify-center text-5xl mb-4"
                style={{ backgroundColor: thumbBg }}>
                {doc.thumbnail_url
                  ? <img src={doc.thumbnail_url} alt={doc.title} className="w-full h-full object-cover rounded-xl" />
                  : emoji}
              </div>

              {doc.category_name && (
                <div className="mb-2">
                  <CategoryBadge name={doc.category_name} slug={doc.category_slug} size="md" />
                </div>
              )}

              <h1 className="text-xl font-semibold text-ink-800 leading-snug mb-3">{doc.title}</h1>

              <div className="flex flex-wrap items-center gap-2 mb-3">
                <LevelBadge level={doc.level} />
                {doc.page_count > 0 && (
                  <span className="flex items-center gap-1 text-xs text-ink-300 bg-ink-50 px-2 py-0.5 rounded">
                    <FileText className="w-3 h-3" /> {doc.page_count} pages
                  </span>
                )}
                {doc.downloads_count > 0 && (
                  <span className="flex items-center gap-1 text-xs text-ink-300 bg-ink-50 px-2 py-0.5 rounded">
                    <Download className="w-3 h-3" /> {doc.downloads_count} téléch.
                  </span>
                )}
                {doc.file_type && (
                  <span className="text-xs text-ink-300 bg-ink-50 px-2 py-0.5 rounded">
                    {doc.file_type.toUpperCase()}
                  </span>
                )}
              </div>

              {doc.rating_count > 0 && (
                <div className="mb-3">
                  <StarRating value={doc.rating_avg} count={doc.rating_count} size="md" />
                </div>
              )}

              {doc.description && (
                <p className="text-sm text-ink-400 leading-relaxed mb-4">{doc.description}</p>
              )}

              {doc.subject_tags?.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {doc.subject_tags.map((tag) => (
                    <span key={tag} className="text-xs bg-ink-50 text-ink-400 px-2 py-0.5 rounded">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              {doc.seller_name && (
                <p className="text-xs text-ink-300 mt-4 pt-4 border-t border-ink-100">
                  Publié par <span className="font-medium text-ink-500">{doc.seller_name}</span>
                </p>
              )}
            </div>

            {/* Avis */}
            {reviews.length > 0 && (
              <div className="card p-5">
                <h2 className="text-sm font-semibold text-ink-800 mb-4">
                  Avis des étudiants
                  <span className="ml-2 text-xs font-normal text-ink-300">({reviews.length})</span>
                </h2>
                <div className="space-y-4">
                  {reviews.map((r, i) => (
                    <div key={i} className={i < reviews.length - 1 ? 'pb-4 border-b border-ink-50' : ''}>
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-primary-50 flex items-center justify-center text-xs font-semibold text-primary-600">
                            {r.reviewer_name?.[0] || '?'}
                          </div>
                          <span className="text-xs font-medium text-ink-700">{r.reviewer_name}</span>
                        </div>
                        <StarRating value={r.rating} />
                      </div>
                      {r.comment && <p className="text-xs text-ink-400 leading-relaxed pl-8">{r.comment}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* ── Bloc achat ── */}
          <div className="lg:col-span-1">
            <div className="card p-5 sticky top-20">
              <div className="text-center mb-4 pb-4 border-b border-ink-100">
                <div className="w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center text-3xl"
                  style={{ backgroundColor: thumbBg }}>
                  {emoji}
                </div>
                <span className="text-2xl font-semibold text-ink-800">
                  {Number(doc.price).toLocaleString('fr-FR')}
                </span>
                <span className="text-xs text-ink-300 ml-1">FCFA</span>
              </div>

              <button onClick={handleAddToCart}
                className={`w-full py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all ${
                  inCart
                    ? 'bg-green-50 text-green-700 cursor-default'
                    : 'bg-primary-600 hover:bg-primary-700 text-white'
                }`}>
                {inCart
                  ? <><Check className="w-4 h-4" /> Dans le panier</>
                  : <><ShoppingCart className="w-4 h-4" /> Ajouter au panier</>}
              </button>

              {inCart && (
                <button onClick={() => navigate('/panier')}
                  className="w-full mt-2 py-2 rounded-lg border border-primary-200 text-primary-600 text-xs font-medium hover:bg-primary-50 transition-all">
                  Voir mon panier →
                </button>
              )}

              <ul className="mt-4 space-y-2">
                {[
                  'Téléchargement immédiat après paiement',
                  'Accès permanent à vie',
                  `Fichier ${doc.file_type?.toUpperCase() || 'PDF'}`,
                  'Paiement sécurisé',
                ].map((perk) => (
                  <li key={perk} className="flex items-center gap-2 text-xs text-ink-400">
                    <Check className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                    {perk}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
