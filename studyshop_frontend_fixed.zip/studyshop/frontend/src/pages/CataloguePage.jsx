import { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, X, ChevronDown } from 'lucide-react';
import { documentsAPI, categoriesAPI } from '../utils/api';
import DocumentCard from '../components/DocumentCard';

const LEVELS = ['Terminale', 'BTS', 'Licence 1', 'Licence 2', 'Licence 3', 'Master 1', 'Master 2'];
const SORT_OPTIONS = [
  { value: 'created_at', label: 'Plus récents'      },
  { value: 'downloads',  label: 'Plus téléchargés'  },
  { value: 'rating',     label: 'Mieux notés'       },
  { value: 'price',      label: 'Prix croissant'    },
];

export default function CataloguePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [documents, setDocuments]       = useState([]);
  const [categories, setCategories]     = useState([]);
  const [pagination, setPagination]     = useState({});
  const [loading, setLoading]           = useState(true);
  const [mobileFilters, setMobileFilters] = useState(false);

  const cat    = searchParams.get('category') || '';
  const level  = searchParams.get('level')    || '';
  const search = searchParams.get('search')   || '';
  const sort   = searchParams.get('sort')     || 'created_at';
  const page   = parseInt(searchParams.get('page') || '1');

  const setParam = (key, value) => {
    const p = new URLSearchParams(searchParams);
    value ? p.set(key, value) : p.delete(key);
    p.delete('page');
    setSearchParams(p);
  };

  const fetchDocs = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await documentsAPI.getAll({
        category: cat   || undefined,
        level:    level || undefined,
        search:   search|| undefined,
        sort, page, limit: 12,
        featured: searchParams.get('featured') || undefined,
      });
      setDocuments(data.documents);
      setPagination(data.pagination);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [cat, level, search, sort, page, searchParams]);

  useEffect(() => { categoriesAPI.getAll().then(r => setCategories(r.data.categories)); }, []);
  useEffect(() => { fetchDocs(); }, [fetchDocs]);

  const hasFilters = cat || level || search;
  const clearAll   = () => setSearchParams({});

  return (
    <div className="min-h-screen bg-ink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7">

        {/* En-tête */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-xl font-semibold text-ink-800">
              {search ? `Résultats pour « ${search} »` : 'Catalogue'}
            </h1>
            {pagination.total !== undefined && (
              <p className="text-xs text-ink-300 mt-0.5">
                {pagination.total} document{pagination.total !== 1 ? 's' : ''} trouvé{pagination.total !== 1 ? 's' : ''}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Tri (desktop) */}
            <div className="relative hidden md:block">
              <select
                value={sort}
                onChange={(e) => setParam('sort', e.target.value)}
                className="input py-1.5 pr-7 text-xs appearance-none cursor-pointer"
              >
                {SORT_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-ink-300 pointer-events-none" />
            </div>

            {/* Bouton filtres mobile */}
            <button
              onClick={() => setMobileFilters(true)}
              className="md:hidden flex items-center gap-1.5 btn-outline py-1.5 px-3 text-xs"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Filtres
              {hasFilters && <span className="w-1.5 h-1.5 rounded-full bg-primary-600" />}
            </button>
          </div>
        </div>

        <div className="flex gap-5">

          {/* ── Sidebar desktop ── */}
          <aside className="hidden md:block w-48 flex-shrink-0">
            <FilterPanel
              categories={categories}
              cat={cat}
              level={level}
              hasFilters={hasFilters}
              setParam={setParam}
              clearAll={clearAll}
            />
          </aside>

          {/* ── Grille principale ── */}
          <div className="flex-1 min-w-0">
            {loading ? (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="card overflow-hidden animate-pulse">
                    <div className="h-16 bg-ink-100" />
                    <div className="p-3 space-y-2">
                      <div className="h-3 bg-ink-100 rounded w-1/2" />
                      <div className="h-4 bg-ink-100 rounded" />
                      <div className="h-7 bg-ink-100 rounded mt-3" />
                    </div>
                  </div>
                ))}
              </div>
            ) : documents.length === 0 ? (
              <div className="text-center py-20">
                <SlidersHorizontal className="w-10 h-10 text-ink-200 mx-auto mb-3" />
                <p className="text-sm font-medium text-ink-400">Aucun document trouvé</p>
                <p className="text-xs text-ink-300 mt-1">Essayez de modifier vos filtres</p>
                <button onClick={clearAll} className="btn-outline mt-4 py-1.5 px-4 text-xs">
                  Effacer les filtres
                </button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                  {documents.map((doc) => <DocumentCard key={doc.id} doc={doc} />)}
                </div>

                {/* Pagination */}
                {pagination.totalPages > 1 && (
                  <div className="flex justify-center items-center gap-1.5 mt-8">
                    <button
                      onClick={() => setParam('page', String(page - 1))}
                      disabled={page <= 1}
                      className="px-3 py-1.5 rounded-lg border border-ink-100 text-xs text-ink-400 hover:bg-ink-50 disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      ← Précédent
                    </button>

                    {[...Array(Math.min(pagination.totalPages, 7))].map((_, i) => {
                      const p = i + 1;
                      return (
                        <button
                          key={p}
                          onClick={() => setParam('page', String(p))}
                          className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                            p === page
                              ? 'bg-primary-600 text-white'
                              : 'border border-ink-100 text-ink-400 hover:bg-ink-50'
                          }`}
                        >
                          {p}
                        </button>
                      );
                    })}

                    <button
                      onClick={() => setParam('page', String(page + 1))}
                      disabled={page >= pagination.totalPages}
                      className="px-3 py-1.5 rounded-lg border border-ink-100 text-xs text-ink-400 hover:bg-ink-50 disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Suivant →
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* ── Drawer filtres mobile ── */}
      {mobileFilters && (
        <div className="md:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-ink-800/40" onClick={() => setMobileFilters(false)} />
          <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl p-5 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-ink-800">Filtres</h3>
              <button onClick={() => setMobileFilters(false)} className="p-1 rounded-lg hover:bg-ink-50">
                <X className="w-4 h-4 text-ink-400" />
              </button>
            </div>
            <FilterPanel
              categories={categories}
              cat={cat}
              level={level}
              hasFilters={hasFilters}
              setParam={(k, v) => { setParam(k, v); setMobileFilters(false); }}
              clearAll={() => { clearAll(); setMobileFilters(false); }}
              mobile
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Panneau de filtres (partagé desktop/mobile) ── */
function FilterPanel({ categories, cat, level, hasFilters, setParam, clearAll, mobile }) {
  return (
    <div className={mobile ? '' : 'card p-4 sticky top-20'}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs font-semibold text-ink-800 flex items-center gap-1.5">
          <SlidersHorizontal className="w-3.5 h-3.5" /> Filtres
        </h3>
        {hasFilters && (
          <button onClick={clearAll} className="text-[10px] text-danger-400 hover:text-danger-600 flex items-center gap-0.5">
            <X className="w-3 h-3" /> Effacer
          </button>
        )}
      </div>

      {/* Matières */}
      <div className="mb-5">
        <p className="text-[10px] font-semibold text-ink-300 uppercase tracking-wider mb-2">Matière</p>
        <div className={mobile ? 'flex flex-wrap gap-2' : 'space-y-0.5'}>
          {mobile ? (
            <>
              <FilterChip label="Toutes" active={!cat} onClick={() => setParam('category', '')} />
              {categories.map((c) => (
                <FilterChip key={c.id} label={c.name} active={cat === c.slug} onClick={() => setParam('category', c.slug)} />
              ))}
            </>
          ) : (
            <>
              <FilterItem label="Toutes" count={null} active={!cat} onClick={() => setParam('category', '')} />
              {categories.map((c) => (
                <FilterItem key={c.id} label={c.name} count={c.document_count} active={cat === c.slug} onClick={() => setParam('category', c.slug)} />
              ))}
            </>
          )}
        </div>
      </div>

      {/* Niveaux */}
      <div>
        <p className="text-[10px] font-semibold text-ink-300 uppercase tracking-wider mb-2">Niveau</p>
        <div className={mobile ? 'flex flex-wrap gap-2' : 'space-y-0.5'}>
          {mobile ? (
            <>
              <FilterChip label="Tous" active={!level} onClick={() => setParam('level', '')} />
              {LEVELS.map((l) => (
                <FilterChip key={l} label={l} active={level === l} onClick={() => setParam('level', l)} />
              ))}
            </>
          ) : (
            <>
              <FilterItem label="Tous" active={!level} onClick={() => setParam('level', '')} />
              {LEVELS.map((l) => (
                <FilterItem key={l} label={l} active={level === l} onClick={() => setParam('level', l)} />
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterItem({ label, count, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-all ${
        active ? 'bg-primary-50 text-primary-700 font-medium' : 'text-ink-400 hover:bg-ink-50 hover:text-ink-700'
      }`}
    >
      <span>{label}</span>
      {count !== null && count !== undefined && (
        <span className={`text-[10px] ${active ? 'text-primary-400' : 'text-ink-300'}`}>{count}</span>
      )}
    </button>
  );
}

function FilterChip({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`text-xs px-3 py-1 rounded-full border transition-all ${
        active
          ? 'bg-primary-600 text-white border-primary-600'
          : 'border-ink-100 text-ink-400 hover:border-primary-200 hover:text-primary-600'
      }`}
    >
      {label}
    </button>
  );
}
