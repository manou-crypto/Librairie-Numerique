import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Download, FileText, CheckCircle, BookOpen } from 'lucide-react';
import { ordersAPI, documentsAPI } from '../utils/api';

export default function PurchasesPage() {
  const [purchases, setPurchases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchParams] = useSearchParams();
  const success = searchParams.get('success');

  useEffect(() => {
    ordersAPI.getPurchases()
      .then(({ data }) => setPurchases(data.purchases))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleDownload = async (docId, title) => {
    try {
      const { data } = await documentsAPI.download(docId);
      if (data.download_url) {
        window.open(data.download_url, '_blank');
      } else {
        alert('URL de téléchargement indisponible');
      }
    } catch (err) {
      alert(err.response?.data?.error || 'Erreur de téléchargement');
    }
  };

  return (
    <div className="min-h-screen bg-ink-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Success banner */}
        {success && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4 mb-6 flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
            <div>
              <p className="font-semibold text-green-800 text-sm">Paiement confirmé !</p>
              <p className="text-green-600 text-xs">Vos documents sont maintenant disponibles au téléchargement.</p>
            </div>
          </div>
        )}

        <h1 className="font-display text-2xl lg:text-3xl font-bold text-ink-900 mb-8 flex items-center gap-3">
          <BookOpen className="w-7 h-7 text-primary-600" />
          Mes documents
        </h1>

        {loading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl border border-ink-100 h-20 animate-pulse" />
            ))}
          </div>
        ) : purchases.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 text-ink-100 mx-auto mb-4" />
            <h2 className="font-semibold text-xl text-ink-900 mb-2">Aucun achat pour l'instant</h2>
            <p className="text-ink-300 mb-6">Explorez notre catalogue pour trouver des ressources d'étude</p>
            <Link to="/catalogue" className="inline-flex items-center gap-2 px-6 py-3 bg-primary-600 text-white font-semibold rounded-2xl hover:bg-primary-700 transition">
              Découvrir le catalogue
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {purchases.map((p) => (
              <div key={p.id} className="bg-white rounded-2xl border border-ink-100 p-4 shadow-card flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl flex-shrink-0 flex items-center justify-center"
                  style={{ backgroundColor: (p.category_color || '#0ea5e9') + '15' }}>
                  <FileText className="w-6 h-6" style={{ color: p.category_color || '#0ea5e9' }} />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-ink-900 text-sm line-clamp-1">{p.title}</h3>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    {p.category_name && <span className="text-xs text-ink-300">{p.category_name}</span>}
                    {p.level && <span className="text-xs bg-ink-50 px-2 py-0.5 rounded-full text-ink-400">{p.level}</span>}
                    <span className="text-xs text-ink-200">
                      Acheté le {new Date(p.purchased_at).toLocaleDateString('fr-FR')}
                    </span>
                  </div>
                </div>

                <button onClick={() => handleDownload(p.id, p.title)}
                  className="flex items-center gap-2 px-4 py-2 bg-primary-50 hover:bg-primary-100 text-primary-700 font-semibold text-sm rounded-xl transition flex-shrink-0">
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Télécharger</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
