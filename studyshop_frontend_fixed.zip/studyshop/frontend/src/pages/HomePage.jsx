import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ArrowRight, BookOpen, Users, Star, LayoutGrid, ChevronRight } from 'lucide-react';
import { documentsAPI, categoriesAPI } from '../utils/api';
import DocumentCard from '../components/DocumentCard';

const CAT_EMOJI = {
  mathematiques:   '∑',
  'physique-chimie':'⚗',
  svt:             '🌿',
  informatique:    '</>',
  langues:         '📖',
  'histoire-geo':  '🌍',
  economie:        '📈',
  philosophie:     '💭',
};
const CAT_BG = {
  mathematiques:  '#EEF3FB',
  'physique-chimie':'#F3F0FC',
  svt:            '#EDF7ED',
  informatique:   '#FEF9E6',
  langues:        '#FEF2EC',
  'histoire-geo': '#F0F4FF',
  economie:       '#FDF0F8',
  philosophie:    '#F0FAFA',
};

const STATS = [
  { icon: BookOpen,   value: '500+',   label: 'Documents',       color: 'text-primary-600', bg: 'bg-primary-50' },
  { icon: Users,      value: '2 000+', label: 'Étudiants',       color: 'text-success-600', bg: 'bg-success-50' },
  { icon: Star,       value: '4,8/5',  label: 'Note moyenne',    color: 'text-warning-600', bg: 'bg-warning-50' },
  { icon: LayoutGrid, value: '8',      label: 'Matières',        color: 'text-violet-600',  bg: 'bg-violet-50'  },
];

export default function HomePage() {
  const [search, setSearch]     = useState('');
  const [featured, setFeatured] = useState([]);
  const [categories, setCategories] = useState([]);
  const [recent, setRecent]     = useState([]);
  const [loading, setLoading]   = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      documentsAPI.getAll({ featured: 'true', limit: 4 }),
      categoriesAPI.getAll(),
      documentsAPI.getAll({ sort: 'created_at', limit: 8 }),
    ]).then(([f, c, r]) => {
      setFeatured(f.data.documents);
      setCategories(c.data.categories);
      setRecent(r.data.documents);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) navigate(`/catalogue?search=${encodeURIComponent(search.trim())}`);
  };

  return (
    <div className="min-h-screen bg-ink-50">

      {/* ── Hero ─────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-primary-50 via-white to-violet-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-20">
          <div className="max-w-xl">
            {/* Tag de disponibilité */}
            <div className="inline-flex items-center gap-2 bg-white border border-ink-100 rounded-full px-3 py-1 text-xs text-primary-600 font-medium mb-5 shadow-card">
              <span className="w-1.5 h-1.5 rounded-full bg-success-400 animate-pulse" />
              500+ documents disponibles
            </div>

            <h1 className="text-3xl lg:text-4xl font-semibold text-ink-800 leading-tight mb-4">
              Réussissez vos études avec les{' '}
              <span className="text-primary-600">meilleurs documents</span>
            </h1>

            <p className="text-sm text-ink-400 leading-relaxed mb-7 max-w-md">
              Cours, exercices corrigés, fiches de révision — trouvez toutes les
              ressources pédagogiques dont vous avez besoin pour progresser.
            </p>

            {/* Barre de recherche */}
            <form onSubmit={handleSearch} className="flex gap-2 max-w-md mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ink-300" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Intégrales terminale, Thermodynamique L2..."
                  className="input pl-9 py-2.5"
                />
              </div>
              <button type="submit" className="btn-primary px-5 py-2.5">
                Chercher
              </button>
            </form>

            {/* Suggestions rapides */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] text-ink-300">Populaires :</span>
              {['Mathématiques', 'Physique', 'Informatique'].map((tag) => (
                <button
                  key={tag}
                  onClick={() => navigate(`/catalogue?search=${tag}`)}
                  className="text-[10px] bg-white border border-ink-100 text-ink-400 hover:text-primary-600 hover:border-primary-200 px-2.5 py-1 rounded-full transition-all"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats ────────────────────────────────────── */}
      <section className="bg-white border-b border-ink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {STATS.map(({ icon: Icon, value, label, color, bg }) => (
              <div key={label} className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${bg}`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div>
                  <div className={`text-base font-semibold ${color}`}>{value}</div>
                  <div className="text-[10px] text-ink-300">{label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Catégories ───────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-semibold text-ink-800">Parcourir par matière</h2>
            <p className="text-xs text-ink-300 mt-0.5">Choisissez votre domaine d'étude</p>
          </div>
          <Link to="/catalogue" className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700">
            Voir tout <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              to={`/catalogue?category=${cat.slug}`}
              className="card group p-3 text-center hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200"
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-xl mx-auto mb-2"
                style={{ backgroundColor: CAT_BG[cat.slug] || '#EEF3FB' }}
              >
                {CAT_EMOJI[cat.slug] || '📄'}
              </div>
              <p className="text-xs font-medium text-ink-800 group-hover:text-primary-600 transition-colors leading-tight">
                {cat.name}
              </p>
              <p className="text-[10px] text-ink-300 mt-0.5">{cat.document_count || 0} docs</p>
            </Link>
          ))}
        </div>
      </section>

      {/* ── Documents populaires ─────────────────────── */}
      {featured.length > 0 && (
        <section className="bg-white border-y border-ink-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-lg font-semibold text-ink-800">Documents populaires</h2>
                <p className="text-xs text-ink-300 mt-0.5">Les plus téléchargés par les étudiants</p>
              </div>
              <Link to="/catalogue?featured=true" className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700">
                Voir plus <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {loading ? (
              <SkeletonGrid count={4} />
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {featured.map((doc) => <DocumentCard key={doc.id} doc={doc} />)}
              </div>
            )}
          </div>
        </section>
      )}

      {/* ── Nouveaux documents ───────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-semibold text-ink-800">Nouveaux documents</h2>
            <p className="text-xs text-ink-300 mt-0.5">Récemment ajoutés au catalogue</p>
          </div>
          <Link to="/catalogue" className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700">
            Catalogue complet <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <SkeletonGrid count={8} />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {recent.map((doc) => <DocumentCard key={doc.id} doc={doc} />)}
          </div>
        )}
      </section>

      {/* ── CTA ──────────────────────────────────────── */}
      <section className="bg-gradient-to-r from-primary-600 to-primary-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h2 className="text-xl font-semibold text-white mb-2">
            Prêt à booster vos études ?
          </h2>
          <p className="text-sm text-primary-100 mb-6 max-w-md mx-auto">
            Rejoignez des milliers d'étudiants qui ont amélioré leurs résultats grâce à StudyShop.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/register" className="inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-white text-primary-700 text-sm font-medium rounded-lg hover:bg-primary-50 transition-all">
              Créer un compte gratuit
              <ChevronRight className="w-4 h-4" />
            </Link>
            <Link to="/catalogue" className="inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-white/10 border border-white/20 text-white text-sm font-medium rounded-lg hover:bg-white/20 transition-all">
              Explorer le catalogue
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

/* Squelette de chargement */
function SkeletonGrid({ count }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
      {[...Array(count)].map((_, i) => (
        <div key={i} className="card overflow-hidden animate-pulse">
          <div className="h-16 bg-ink-100" />
          <div className="p-3 space-y-2">
            <div className="h-3 bg-ink-100 rounded w-1/2" />
            <div className="h-4 bg-ink-100 rounded w-full" />
            <div className="h-3 bg-ink-100 rounded w-3/4" />
            <div className="h-7 bg-ink-100 rounded mt-3" />
          </div>
        </div>
      ))}
    </div>
  );
}
