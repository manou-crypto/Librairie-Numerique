import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, Trash2, ArrowRight, FileText, Lock, ChevronRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { ordersAPI } from '../utils/api';

export default function CartPage() {
  const { items, total, removeFromCart, refetchCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const navigate = useNavigate();

  const CAT_BG = {
    mathematiques: '#EEF3FB', 'physique-chimie': '#F3F0FC', svt: '#EDF7ED',
    informatique: '#FEF9E6', langues: '#FEF2EC', 'histoire-geo': '#F0F4FF',
    economie: '#FDF0F8', philosophie: '#F0FAFA',
  };
  const CAT_EMOJI = { mathematiques:'∑', 'physique-chimie':'⚗', svt:'🌿', informatique:'</>', langues:'📖', 'histoire-geo':'🌍', economie:'📈', philosophie:'💭' };

  const handleCheckout = async () => {
    setLoading(true);
    setError('');
    try {
      const { data } = await ordersAPI.create();
      await ordersAPI.confirm(data.order.id);
      await refetchCart();
      navigate('/mes-achats?success=true');
    } catch (err) {
      setError(err.response?.data?.error || 'Erreur lors de la commande');
    } finally {
      setLoading(false);
    }
  };

  /* Panier vide */
  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-ink-50 flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-ink-100 flex items-center justify-center mx-auto mb-4">
            <ShoppingCart className="w-7 h-7 text-ink-300" />
          </div>
          <h2 className="text-lg font-semibold text-ink-800 mb-1">Votre panier est vide</h2>
          <p className="text-sm text-ink-300 mb-5">Découvrez notre catalogue de documents d'études</p>
          <Link to="/catalogue" className="btn-primary">
            Explorer le catalogue <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-ink-50 py-7">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Titre */}
        <div className="flex items-center gap-2 mb-6">
          <ShoppingCart className="w-5 h-5 text-primary-600" />
          <h1 className="text-xl font-semibold text-ink-800">Mon panier</h1>
          <span className="text-sm text-ink-300">({items.length} article{items.length > 1 ? 's' : ''})</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

          {/* ── Liste des articles ── */}
          <div className="lg:col-span-2 space-y-3">
            {items.map((item) => (
              <div key={item.document_id} className="card p-3 flex items-center gap-3">
                {/* Icône */}
                <div
                  className="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center text-lg"
                  style={{ backgroundColor: CAT_BG[item.category_slug] || '#EEF3FB' }}
                >
                  {CAT_EMOJI[item.category_slug] || '📄'}
                </div>

                {/* Infos */}
                <div className="flex-1 min-w-0">
                  <Link
                    to={`/document/${item.document_id}`}
                    className="text-sm font-medium text-ink-800 hover:text-primary-600 transition-colors line-clamp-1"
                  >
                    {item.title}
                  </Link>
                  <div className="flex items-center gap-2 mt-0.5">
                    {item.category_name && (
                      <span className="text-[10px] text-ink-300">{item.category_name}</span>
                    )}
                    {item.level && (
                      <span className="text-[10px] bg-ink-50 px-1.5 py-0.5 rounded text-ink-400">{item.level}</span>
                    )}
                  </div>
                </div>

                {/* Prix + supprimer */}
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className="text-sm font-semibold text-ink-800 whitespace-nowrap">
                    {Number(item.price).toLocaleString('fr-FR')}
                    <span className="text-[10px] font-normal text-ink-300 ml-0.5">FCFA</span>
                  </span>
                  <button
                    onClick={() => removeFromCart(item.document_id)}
                    className="p-1.5 rounded-lg text-ink-200 hover:text-danger-400 hover:bg-danger-50 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            <Link to="/catalogue" className="flex items-center gap-1.5 text-xs text-ink-400 hover:text-primary-600 transition-colors mt-2">
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
              Continuer mes achats
            </Link>
          </div>

          {/* ── Récapitulatif ── */}
          <div className="lg:col-span-1">
            <div className="card p-4 sticky top-20">
              <h2 className="text-sm font-semibold text-ink-800 mb-4">Récapitulatif</h2>

              {/* Lignes */}
              <div className="space-y-2 mb-4">
                {items.map((item) => (
                  <div key={item.document_id} className="flex justify-between text-xs gap-2">
                    <span className="text-ink-400 truncate">{item.title}</span>
                    <span className="text-ink-600 font-medium flex-shrink-0">
                      {Number(item.price).toLocaleString('fr-FR')} FCFA
                    </span>
                  </div>
                ))}
              </div>

              {/* Total */}
              <div className="flex justify-between items-center py-3 border-t border-b border-ink-100 mb-4">
                <span className="text-sm font-semibold text-ink-800">Total</span>
                <span className="text-base font-semibold text-ink-800">
                  {total.toLocaleString('fr-FR')}
                  <span className="text-xs font-normal text-ink-300 ml-1">FCFA</span>
                </span>
              </div>

              {error && (
                <div className="bg-danger-50 text-danger-600 text-xs rounded-lg px-3 py-2 mb-3">
                  {error}
                </div>
              )}

              <button
                onClick={handleCheckout}
                disabled={loading}
                className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 text-white text-sm font-medium rounded-lg transition-all flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {loading ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <><Lock className="w-3.5 h-3.5" /> Commander</>
                )}
              </button>

              <p className="text-[10px] text-center text-ink-300 mt-2 flex items-center justify-center gap-1">
                <Lock className="w-3 h-3" /> Paiement sécurisé · Accès immédiat
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
