import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, FileText, Download, Check } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import StarRating from './StarRating';
import CategoryBadge from './CategoryBadge';
import LevelBadge from './LevelBadge';

/* Emoji par catégorie */
const CAT_EMOJI = {
  mathematiques:  '∑',
  'physique-chimie': '⚗',
  svt:            '🌿',
  informatique:   '</>',
  langues:        '📖',
  'histoire-geo': '🌍',
  economie:       '📈',
  philosophie:    '💭',
};

/* Couleur de fond de la vignette */
const CAT_BG = {
  mathematiques:  '#EEF3FB',
  'physique-chimie': '#F3F0FC',
  svt:            '#EDF7ED',
  informatique:   '#FEF9E6',
  langues:        '#FEF2EC',
  'histoire-geo': '#F0F4FF',
  economie:       '#FDF0F8',
  philosophie:    '#F0FAFA',
};

export default function DocumentCard({ doc }) {
  const { addToCart, isInCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const inCart = isInCart(doc.id);

  const handleAddToCart = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) return navigate('/login');
    if (!inCart) await addToCart(doc.id);
  };

  const thumbBg = CAT_BG[doc.category_slug] || '#EEF3FB';
  const emoji   = CAT_EMOJI[doc.category_slug] || '📄';

  return (
    <Link
      to={`/document/${doc.id}`}
      className="card group flex flex-col overflow-hidden hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200"
    >
      {/* Vignette */}
      <div
        className="h-16 flex items-center justify-center text-3xl flex-shrink-0 relative"
        style={{ backgroundColor: thumbBg }}
      >
        {doc.thumbnail_url ? (
          <img src={doc.thumbnail_url} alt={doc.title} className="w-full h-full object-cover" />
        ) : (
          <span>{emoji}</span>
        )}
        {doc.is_featured && (
          <span className="absolute top-1.5 right-1.5 badge bg-accent-400 text-white text-[10px]">
            ⭐ Populaire
          </span>
        )}
      </div>

      {/* Contenu */}
      <div className="p-3 flex flex-col flex-1 gap-2">
        {/* Catégorie */}
        {doc.category_name && (
          <CategoryBadge name={doc.category_name} slug={doc.category_slug} />
        )}

        {/* Titre */}
        <h3 className="text-sm font-medium text-ink-800 line-clamp-2 leading-snug group-hover:text-primary-600 transition-colors">
          {doc.title}
        </h3>

        {/* Meta */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <LevelBadge level={doc.level} />
          {doc.page_count > 0 && (
            <span className="flex items-center gap-0.5 text-[10px] text-ink-300">
              <FileText className="w-3 h-3" />
              {doc.page_count}p
            </span>
          )}
          {doc.downloads_count > 0 && (
            <span className="flex items-center gap-0.5 text-[10px] text-ink-300">
              <Download className="w-3 h-3" />
              {doc.downloads_count}
            </span>
          )}
        </div>

        {/* Note */}
        {doc.rating_count > 0 && (
          <StarRating value={doc.rating_avg} count={doc.rating_count} />
        )}

        {/* Prix + bouton */}
        <div className="flex items-center justify-between mt-auto pt-2 border-t border-ink-100">
          <span className="text-sm font-semibold text-ink-800">
            {Number(doc.price).toLocaleString('fr-FR')}
            <span className="text-[10px] font-normal text-ink-300 ml-0.5">FCFA</span>
          </span>
          <button
            onClick={handleAddToCart}
            className={`flex items-center gap-1 text-[10px] font-medium px-2.5 py-1 rounded-lg transition-all ${
              inCart
                ? 'bg-success-50 text-success-600 cursor-default'
                : 'bg-primary-50 text-primary-600 hover:bg-primary-600 hover:text-white'
            }`}
          >
            {inCart ? (
              <><Check className="w-3 h-3" /> Ajouté</>
            ) : (
              <><ShoppingCart className="w-3 h-3" /> Acheter</>
            )}
          </button>
        </div>
      </div>
    </Link>
  );
}
