/* Badge coloré selon la catégorie */
const CATEGORY_STYLES = {
  mathematiques: { bg: '#EEF3FB', color: '#2F5C9E' },
  'physique-chimie': { bg: '#F3F0FC', color: '#5A40A0' },
  svt:           { bg: '#EDF7ED', color: '#2A6030' },
  informatique:  { bg: '#FEF9E6', color: '#906010' },
  langues:       { bg: '#FEF2EC', color: '#883820' },
  'histoire-geo':{ bg: '#F0F4FF', color: '#3040A0' },
  economie:      { bg: '#FDF0F8', color: '#883068' },
  philosophie:   { bg: '#F0FAFA', color: '#206868' },
};
const DEFAULT = { bg: '#EEF3FB', color: '#2F5C9E' };

export default function CategoryBadge({ name, slug, size = 'sm' }) {
  const style = CATEGORY_STYLES[slug] || DEFAULT;
  const padding = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-block font-medium rounded-full ${padding}`}
      style={{ backgroundColor: style.bg, color: style.color }}
    >
      {name}
    </span>
  );
}
