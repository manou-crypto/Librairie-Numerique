import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { ShoppingCart, BookOpen, Search, User, LogOut, Menu, X, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { user, logout, isAdmin } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) navigate(`/catalogue?search=${encodeURIComponent(search.trim())}`);
  };

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-ink-100 shadow-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center h-14 gap-4">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 flex-shrink-0">
            <div className="w-7 h-7 rounded-lg bg-primary-600 flex items-center justify-center">
              <BookOpen className="w-3.5 h-3.5 text-white" strokeWidth={2.5} />
            </div>
            <span className="text-sm font-semibold text-ink-800">
              Study<span className="text-primary-600">Shop</span>
            </span>
          </Link>

          {/* Nav links (desktop) */}
          <div className="hidden md:flex items-center gap-0.5">
            {[
              { to: '/', label: 'Accueil' },
              { to: '/catalogue', label: 'Catalogue' },
            ].map(({ to, label }) => (
              <Link
                key={to}
                to={to}
                className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                  isActive(to)
                    ? 'bg-primary-50 text-primary-600 font-medium'
                    : 'text-ink-400 hover:text-ink-800 hover:bg-ink-50'
                }`}
              >
                {label}
              </Link>
            ))}
          </div>

          {/* Search (desktop) */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xs ml-2">
            <div className="relative w-full">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ink-300" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Rechercher un cours, exercice..."
                className="input pl-8 py-1.5 text-xs"
              />
            </div>
          </form>

          {/* Right actions */}
          <div className="flex items-center gap-1.5 ml-auto">
            {user ? (
              <>
                {isAdmin && (
                  <Link to="/admin" className="btn-ghost hidden md:inline-flex text-xs">
                    <LayoutDashboard className="w-3.5 h-3.5" />
                    Admin
                  </Link>
                )}
                <Link to="/mes-achats" className="btn-ghost hidden md:inline-flex text-xs">
                  <User className="w-3.5 h-3.5" />
                  {user.full_name?.split(' ')[0]}
                </Link>
                <Link to="/panier" className="relative p-2 rounded-lg text-ink-400 hover:text-primary-600 hover:bg-primary-50 transition-all">
                  <ShoppingCart className="w-4 h-4" />
                  {itemCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-accent-400 text-white text-[10px] rounded-full flex items-center justify-center font-semibold">
                      {itemCount}
                    </span>
                  )}
                </Link>
                <button
                  onClick={() => { logout(); navigate('/'); }}
                  className="hidden md:flex p-2 rounded-lg text-ink-300 hover:text-danger-400 hover:bg-danger-50 transition-all"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-ghost hidden md:inline-flex text-xs">
                  Connexion
                </Link>
                <Link to="/register" className="btn-primary py-1.5 px-3 text-xs">
                  S'inscrire
                </Link>
              </>
            )}

            {/* Mobile toggle */}
            <button
              className="md:hidden p-2 rounded-lg text-ink-400 hover:bg-ink-50"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-ink-100 bg-white px-4 py-3 space-y-1">
          <form onSubmit={handleSearch} className="relative mb-3">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ink-300" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher..."
              className="input pl-8 py-1.5 text-xs"
            />
          </form>
          <Link to="/" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm text-ink-600 hover:bg-ink-50">Accueil</Link>
          <Link to="/catalogue" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm text-ink-600 hover:bg-ink-50">Catalogue</Link>
          {user ? (
            <>
              <Link to="/panier" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm text-ink-600 hover:bg-ink-50">
                Panier ({itemCount})
              </Link>
              <Link to="/mes-achats" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm text-ink-600 hover:bg-ink-50">Mes achats</Link>
              <button onClick={() => { logout(); navigate('/'); setMobileOpen(false); }} className="block w-full text-left px-3 py-2 rounded-lg text-sm text-danger-400 hover:bg-danger-50">
                Déconnexion
              </button>
            </>
          ) : (
            <>
              <Link to="/login" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm text-ink-600 hover:bg-ink-50">Connexion</Link>
              <Link to="/register" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm text-primary-600 font-medium hover:bg-primary-50">S'inscrire</Link>
            </>
          )}
        </div>
      )}
    </nav>
  );
}
