/* Affiche des étoiles (lecture seule ou cliquables) */
export default function StarRating({ value = 0, count = 0, size = 'sm', interactive = false, onChange }) {
  const sz = size === 'sm' ? 'text-xs' : 'text-sm';

  return (
    <div className="flex items-center gap-1">
      <div className="flex">
        {[1, 2, 3, 4, 5].map((s) => (
          <span
            key={s}
            className={`${sz} ${s <= Math.round(value) ? 'star-filled' : 'star-empty'} ${interactive ? 'cursor-pointer hover:scale-110 transition-transform' : ''}`}
            onClick={() => interactive && onChange?.(s)}
          >
            ★
          </span>
        ))}
      </div>
      {count > 0 && (
        <span className="text-[10px] text-ink-300">({count})</span>
      )}
    </div>
  );
}
