/* Badge de niveau d'étude */
const LEVEL_COLORS = {
  'Terminale': 'bg-violet-50 text-violet-600',
  'BTS':       'bg-warning-50 text-amber-700',
  'Licence 1': 'bg-primary-50 text-primary-700',
  'Licence 2': 'bg-primary-50 text-primary-700',
  'Licence 3': 'bg-primary-50 text-primary-700',
  'Master 1':  'bg-success-50 text-success-600',
  'Master 2':  'bg-success-50 text-success-600',
};

export default function LevelBadge({ level }) {
  if (!level) return null;
  const cls = LEVEL_COLORS[level] || 'bg-ink-50 text-ink-400';
  return (
    <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${cls}`}>
      {level}
    </span>
  );
}
