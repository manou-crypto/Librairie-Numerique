import { Link } from 'react-router-dom';
import { BookOpen } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-ink-100 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">

          {/* Brand */}
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-primary-600 flex items-center justify-center">
                <BookOpen className="w-3.5 h-3.5 text-white" strokeWidth={2.5} />
              </div>
              <span className="text-sm font-semibold text-ink-800">
                Study<span className="text-primary-600">Shop</span>
              </span>
            </Link>
            <p className="text-xs text-ink-300 leading-relaxed">
              La plateforme de référence pour les documents d'études en Afrique francophone.
            </p>
          </div>

          {/* Catalogue */}
          <div>
            <h4 className="text-xs font-semibold text-ink-800 mb-3 uppercase tracking-wide">Catalogue</h4>
            <ul className="space-y-2">
              {['Mathématiques', 'Physique-Chimie', 'Informatique', 'Langues', 'SVT'].map((c) => (
                <li key={c}>
                  <Link to={`/catalogue?category=${c.toLowerCase().replace(' ', '-')}`} className="text-xs text-ink-400 hover:text-primary-600 transition-colors">
                    {c}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Mon compte */}
          <div>
            <h4 className="text-xs font-semibold text-ink-800 mb-3 uppercase tracking-wide">Mon compte</h4>
            <ul className="space-y-2">
              {[
                { label: 'Connexion', to: '/login' },
                { label: 'Inscription', to: '/register' },
                { label: 'Mes achats', to: '/mes-achats' },
                { label: 'Mon panier', to: '/panier' },
              ].map(({ label, to }) => (
                <li key={to}>
                  <Link to={to} className="text-xs text-ink-400 hover:text-primary-600 transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Infos */}
          <div>
            <h4 className="text-xs font-semibold text-ink-800 mb-3 uppercase tracking-wide">Informations</h4>
            <ul className="space-y-2">
              {['À propos', 'CGV', 'Politique de confidentialité', 'Contact'].map((item) => (
                <li key={item}>
                  <span className="text-xs text-ink-400 hover:text-primary-600 transition-colors cursor-pointer">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-ink-100 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[10px] text-ink-300">© {new Date().getFullYear()} StudyShop. Tous droits réservés.</p>
          <div className="flex items-center gap-1.5 text-[10px] text-ink-300">
            <span className="w-1.5 h-1.5 rounded-full bg-success-400 animate-pulse" />
            Paiements sécurisés
          </div>
        </div>
      </div>
    </footer>
  );
}
