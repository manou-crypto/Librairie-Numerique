import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { cartAPI } from '../utils/api';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);

  const fetchCart = useCallback(async () => {
    if (!user) { setItems([]); setTotal(0); return; }
    try {
      setLoading(true);
      const { data } = await cartAPI.get();
      setItems(data.items);
      setTotal(data.total);
    } catch (err) {
      console.error('Cart fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => { fetchCart(); }, [fetchCart]);

  const addToCart = useCallback(async (documentId) => {
    await cartAPI.add(documentId);
    await fetchCart();
  }, [fetchCart]);

  const removeFromCart = useCallback(async (documentId) => {
    await cartAPI.remove(documentId);
    await fetchCart();
  }, [fetchCart]);

  const isInCart = useCallback((documentId) =>
    items.some((i) => i.document_id === documentId), [items]);

  return (
    <CartContext.Provider value={{ items, total, loading, addToCart, removeFromCart, isInCart, refetchCart: fetchCart, itemCount: items.length }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart doit être utilisé dans CartProvider');
  return ctx;
};
