import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({ baseURL: API_URL });

// Intercepteur : ajouter le token JWT automatiquement
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Intercepteur : gérer l'expiration de session
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ─── Auth ─────────────────────────────────────────────
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
};

// ─── Documents ────────────────────────────────────────
export const documentsAPI = {
  getAll: (params) => api.get('/documents', { params }),
  getById: (id) => api.get(`/documents/${id}`),
  create: (data) => api.post('/documents', data),
  update: (id, data) => api.patch(`/documents/${id}`, data),
  delete: (id) => api.delete(`/documents/${id}`),
  download: (id) => api.get(`/documents/${id}/download`),
  addReview: (id, data) => api.post(`/documents/${id}/reviews`, data),
};

// ─── Categories ───────────────────────────────────────
export const categoriesAPI = {
  getAll: () => api.get('/categories'),
};

// ─── Cart ─────────────────────────────────────────────
export const cartAPI = {
  get: () => api.get('/cart'),
  add: (documentId) => api.post(`/cart/${documentId}`),
  remove: (documentId) => api.delete(`/cart/${documentId}`),
};

// ─── Orders ───────────────────────────────────────────
export const ordersAPI = {
  create: () => api.post('/orders'),
  confirm: (orderId) => api.post(`/orders/${orderId}/confirm`),
  getAll: () => api.get('/orders'),
  getPurchases: () => api.get('/purchases'),
};

// ─── Admin ────────────────────────────────────────────
export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
};

export default api;
