/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50:  '#EEF3FB',
          100: '#D8E6F5',
          200: '#B5CCE8',
          400: '#7AAAE0',
          600: '#4F80C8',
          700: '#2F5C9E',
          800: '#1C3D72',
          900: '#0E2448',
        },
        accent: {
          50:  '#FEF2EC',
          100: '#FAD9C5',
          200: '#F5B89A',
          400: '#F08060',
          600: '#C85A38',
          800: '#8C3820',
        },
        violet: {
          50:  '#F3F0FC',
          100: '#E0D8F8',
          400: '#A87CC8',
          600: '#7A60C0',
          800: '#4A3880',
        },
        ink: {
          50:  '#F4F6FA',
          100: '#E8EDF5',
          200: '#D0D8E8',
          300: '#B0BAC8',
          400: '#8A95A8',
          600: '#4A5568',
          800: '#1C2B4A',
          900: '#0E1A30',
        },
        success: {
          50:  '#EDF7ED',
          400: '#7BC47A',
          600: '#3A8040',
        },
        warning: {
          50:  '#FEF9E6',
          400: '#F5C842',
          600: '#B8900E',
        },
        danger: {
          50:  '#FDECEA',
          400: '#E86050',
          600: '#A83020',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px 0 rgba(28,43,74,0.06), 0 1px 2px -1px rgba(28,43,74,0.04)',
        'card-hover': '0 4px 12px -2px rgba(28,43,74,0.10)',
        'input-focus': '0 0 0 3px rgba(79,128,200,0.15)',
      },
    },
  },
  plugins: [],
};
